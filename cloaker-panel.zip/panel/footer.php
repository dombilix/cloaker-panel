  </main>
  <script src="/panel/assets/js/scripts.bundle.js"></script>
  <script src="/panel/assets/js/widgets.bundle.js"></script>
</body>
</html>
