<!DOCTYPE html>
<html lang="tr">
<head><meta charset="UTF-8"><title>Sağlık Portalı</title>
<style>body{font-family:Arial,sans-serif;background:#f5f5f5;color:#333;text-align:center;padding:50px;}
h1{color:#2e7d32;}p{font-size:18px;}</style></head>
<body><h1>Hoşgeldiniz!</h1><p>Bu sahte sağlık portalıdır. Gerçek siteye erişim için uygun koşulları sağlayınız.</p></body>
</html>